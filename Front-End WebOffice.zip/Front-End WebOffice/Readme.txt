Step-1: npm install
Step-2 Copy path server and use terminal 
step-3 cd fsd-project\server
Step-4 npm start
It will take us to the website