import React from "react";

export default function Editemployee(props) {
  return (
    <div id="edit_employee" class="modal custom-modal fade" role="dialog" aria-modal="true" >
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Employee</h5>
            <button
              type="button"
              class="close"
              data-bs-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
            <form class="editform" action={`/editemployee/${props.emp.id}`} method="post">
              <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                                <label class="col-form-label">First Name <span class="text-danger">*</span></label>
                                <input
                                class="form-control"
                                name="fname"
                                defaultValue={props.emp.Name}
                                type="text"
                                />
                        </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label">Last Name</label>
                        <input
                        class="form-control"
                        name="lname"
                        defaultValue="<%= e.lname %>"
                        type="text"
                        />
                    </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label">
                        Username <span class="text-danger">*</span>
                        </label>
                        <input
                        class="form-control"
                        name="uname"
                        defaultValue="<%= e.uname %>"
                        type="text"
                        />
                    </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label">
                        Email <span class="text-danger">*</span>
                        </label>
                        <input
                        class="form-control"
                        name="email"
                        defaultValue="<%= e.email %>"
                        type="email"
                        />
                    </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label">
                        Employee ID <span class="text-danger">*</span>
                        </label>
                        <input
                        type="text"
                        defaultValue="<%= e._id %>"
                        readOnly=""
                        name="_id"
                        class="form-control floating"
                        />
                    </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label">
                        Joining Date <span class="text-danger">*</span>
                        </label>
                        <div class="cal-icon">
                        <input
                            class="form-control datetimepicker"
                            defaultValue="<%= e.jdate %>"
                            name="jdate"
                            type="text"
                        />
                        </div>
                    </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label">Phone </label>
                        <input
                        class="form-control"
                        name="phone"
                        defaultValue="<%= e.phone %>"
                        type="text"
                        />
                    </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label">Company</label>
                        <select
                        class="select"
                        name="company"
                        tabindex="-1"
                        aria-hidden="true"
                        >
                        <option defaultValue="">Select Company</option>
                        <option defaultValue="Global Technologies">
                            Global Technologies
                        </option>
                        <option defaultValue="Delta Infotech">Delta Infotech</option>
                        </select>
                    </div>
                    </div>
                    <div class="col-md-6">
                    <div class="form-group">
                        <label>
                        Department <span class="text-danger">*</span>
                        </label>
                        <select
                        class="select"
                        name="department"
                        tabindex="-1"
                        aria-hidden="true"
                        >
                        <option defaultValue="">Select Department</option>
                        <option defaultValue="Web Development">Web Development</option>
                        <option defaultValue="IT Management">IT Management</option>
                        <option defaultValue="Marketing">Marketing</option>
                        </select>
                    </div>
                    </div>
                    <div class="col-md-6">
                    <div class="form-group">
                        <label>
                        Designation <span class="text-danger">*</span>
                        </label>
                        <select
                        class="select"
                        name="designation"
                        tabindex="-1"
                        aria-hidden="true"
                        >
                        <option defaultValue="">Select Designation</option>
                        <option defaultValue="Web Designer">Web Designer</option>
                        <option defaultValue="Web Developer">Web Developer</option>
                        <option defaultValue="Android Developer">
                            Android Developer
                        </option>
                        </select>
                    </div>
                    </div>
              </div>
              <div class="submit-section">
                    <button type="submit" class="btn btn-primary submit-btn">Save</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
