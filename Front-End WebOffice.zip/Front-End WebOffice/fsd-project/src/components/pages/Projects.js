import React from 'react'
import Dashboardtemplate from "../UI/Dashboardtemplate";
import "../../public/assests/projects.css"

export default function Projects() {
  return (
    <Dashboardtemplate>

        {/* <!-- Page Header --> */}
        <div className="page-header">
            <div className="row align-items-center">
                <div className="col">
                    <h3 className="page-title">Projects</h3>
                    <ul className="breadcrumb">
                        <li className="breadcrumb-item">
                            <a href="/dashboard">Dashboard</a>
                        </li>
                        <li className="breadcrumb-item active">Projects</li>
                    </ul>
                </div>
                <div className="col-auto float-end ms-auto">
                    <a href="#" className="btn add-btn" data-bs-toggle="modal" data-bs-target="#create_project"><i
                            className="fa fa-plus"></i> Create Project</a>
                    <div className="view-icons">
                        <a href="/projects" className="grid-view btn active"><i
                                className="fa fa-th"></i></a>
                        <a href="#" className="list-view btn"><i className="fa fa-bars"></i></a>
                    </div>
                </div>
            </div>
        </div>
        
        {/* <!-- Search bar  --> */}
        <div className="row filter-row">
            <div className="col-sm-6 col-md-3">
                <div className="form-group form-focus">
                    <input type="text" className="form-control floating" placeholder="Project Name"/>
                </div>
            </div>
            <div className="col-sm-6 col-md-3">
                <div className="form-group form-focus">
                    <input type="text" className="form-control floating" placeholder="Employee Name"/>
                </div>
            </div>
            <div className="col-sm-6 col-md-3">
                <div className="form-group form-focus">
                    <select className="select-focus">
                        <option>Designation</option>
                        <option>Web Developer</option>
                        <option>Web Designer</option>
                        <option>Android Developer</option>
                        <option>Ios Developer</option>
                    </select>
                </div>
            </div>
            <div className="col-sm-6 col-md-3">
                <a href="#" className="btn btn-success btn-block"> Search </a>
            </div>
        </div>

        

    </Dashboardtemplate>
  )
}
