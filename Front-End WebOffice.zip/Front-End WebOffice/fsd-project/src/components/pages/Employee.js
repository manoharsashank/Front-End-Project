import React from "react";
import { useState } from "react";
import Dashboardtemplate from "../UI/Dashboardtemplate";
import "../../public/assests/employee.css";
import Addemployee from "../popup-models/Addemployee";
import Editemployee from "../popup-models/Editemployee";
import Deleteemployee from "../popup-models/Deleteemployee";

export default function Employee() {
  let Employees = [
    {
      id: "101",
      Name: "Vd",
      Designation: "Web Developer",
    },
    {
      id: "102",
      Name: "Santos",
      Designation: "Marketing",
    }
  ];

  const NULLURL = ""
  const [Emp, setEmp] = useState({})

  const EmployeeHandler = (event, eId) => {
    Employees.forEach(employee => {
      if(employee.id === eId) {
        console.log(employee);
        setEmp(employee);
        return;
      }
    })
    // console.log(event, editId);
  };

  let EmployeeList = <p className="emptylist">No Employees Found</p>;

  if (Employees.length > 0) {
    EmployeeList = Employees.map((e) => (
        <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
            <div className="profile-widget">
              <div className="profile-img">
                <a href="/profile" className="avatar">
                  <img src={require("../../public/Images/review3.png")} alt="" />
                </a>
              </div>
              <div className="dropdown profile-action">
                <a
                  href={NULLURL}
                  className="action-icon dropdown-toggle"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <i className="fa-solid fa-ellipsis-vertical"></i>
                </a>
                <div className="dropdown-menu dropdown-menu-right">
                  <a href={NULLURL} className="dropdown-item" data-bs-toggle="modal" data-bs-target="#edit_employee" onClick={event => EmployeeHandler(event, e.id)} >
                    <i className="fa fa-pencil m-r-5"></i> Edit
                  </a>
                  <a href={NULLURL} class="dropdown-item" data-bs-toggle="modal" data-bs-target="#delete_employee" onClick={event => EmployeeHandler(event, e.id)}>
                    <i class="fa fa-trash-o m-r-5"></i> Delete
                  </a>
                  {/* <a className="dropdown-item" href={`/edit/:${e.id}`}  >
                    <i className="fa fa-pencil m-r-5"></i> Edit
                  </a> */}
                  {/* <a className="dropdown-item" href={`/deleteemployee/:${e.id}`}>
                    <i className="fa fa-trash-o m-r-5"></i> Delete
                  </a> */}
                </div>
              </div>
              <h4 className="user-name m-t-10 mb-0 text-ellipsis">
                <a href="/profile">{e.Name}</a>
              </h4>
              <div className="small text-muted">{e.Designation}</div>
            </div>
        </div>
    ));
  }

  return (
    <Dashboardtemplate>
      {/* <!-- Page Header --> */}
      <div className="page-header">
        <div className="row">
          <div className="col">
            <h3 className="page-title">Employee</h3>
            <ul className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="/dashboard">Dashboard</a>
              </li>
              <li className="breadcrumb-item active">Employee</li>
            </ul>
          </div>

          <div className="col-auto float-right ml-auto">
            <a
              href={NULLURL}
              className="btn add-btn"
              data-bs-toggle="modal"
              data-bs-target="#add_employee"
            >
              <i className="fa fa-plus"></i> Add Employee
            </a>
          </div>
        </div>
      </div>

      {/* <!-- Search bar  --> */}
      <div className="row filter-row">
        <div className="col-sm-6 col-md-3">
          <div className="form-group form-focus">
            <input
              type="text"
              className="form-control floating"
              placeholder="Project Name"
            />
          </div>
        </div>
        <div className="col-sm-6 col-md-3">
          <div className="form-group form-focus">
            <input
              type="text"
              className="form-control floating"
              placeholder="Employee Name"
            />
          </div>
        </div>
        <div className="col-sm-6 col-md-3">
          <div className="form-group form-focus">
            <select className="select-focus">
              <option>Designation</option>
              <option>Web Developer</option>
              <option>Web Designer</option>
              <option>Android Developer</option>
              <option>Ios Developer</option>
            </select>
          </div>
        </div>
        <div className="col-sm-6 col-md-3">
          <a href={NULLURL} className="btn btn-success btn-block">
            {" "}
            Search{" "}
          </a>
        </div>
      </div>

      {/* employees list */}
      <div className="row staff-grid-row">
        {EmployeeList}
      </div>

      <Addemployee/>
      <Editemployee emp = {Emp} />
      <Deleteemployee emp = {Emp} />

    </Dashboardtemplate>
  );
}
