// import './App.css';
import { BrowserRouter as Router,Routes, Route} from "react-router-dom";
import Home from "./components/pages/Home"
import Dashboard from "./components/pages/Dashboard"
import Employee from "./components/pages/Employee"
import Login from "./components/pages/Login"
import Projects from "./components/pages/Projects";

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route index element={<Home/>} />
          <Route path="/dashboard" element={<Dashboard/>} />
          <Route path="/employee" element={<Employee/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/projects" element={<Projects/>} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
