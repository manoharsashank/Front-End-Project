const mongoose = require("mongoose");
const express = require("express");
const app = express();
const cors = require("cors");
const route = require("./router/auth").default;
app.use(express.json());
app.use(route);
app.use(cors());
app.listen(8000, () => {
    console.log("Website running on port:8000");
});


mongoose
    .connect("mongodb://localhost:27017/React", {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    })
    .then(() => {
        console.log("Connection to MONGO successful");
    })
    .catch((err) => {
        console.log(err);
    });


// eslint-disable-next-line no-unused-vars
const middleware = (req, res, next) => {
    console.log("in middleware");
    next();
};

