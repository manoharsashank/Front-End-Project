const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
class User {
    constructor() {
        this.name = {
            type: String,
        };
        this.email = {
            type: String,
        };
        this.password = {
            type: String,
        };
        this.tokens = [
            {
                token: {
                    type: String,
                },
            },
        ];
    }
}
const userSchema = new mongoose.Schema(new User());

userSchema.pre("save", async function (next) {
    if (this.isModified("password")) {
        this.password = await bcrypt.hash(this.password, 12);
    }
    next();
});


userSchema.methods.generateAuthToken = async function () {
    try {
        let token = jwt.sign(
            { _id: this._id },
            "iamvaibhavdasaristudyinginindianinstituteofinformationtechnologysricity"
        );
        this.tokens = this.tokens.concat({ token: token });
        await this.save();
        return token;
    } catch (error) {
        console.log(error);
    }
};





module.exports = mongoose.model("User", userSchema);
